# Oefening 6: Som van de eerste n positieve gehele getallen
n = float(input("Positief geheel getal: "))
n = (n)*(n + 1)/2

print(n)