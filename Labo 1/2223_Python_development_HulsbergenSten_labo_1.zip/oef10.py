# Oefening 10: Celsius naar Fahrenheit en Kelvin
c = float(input("Geef een graad in (°C): "))
f = c * 33.8
k = c * 274.15
print(f"{c}°C = {f}°F = {k}°K")
