# Oefening 3: Hallo!
naam = input("Naam: ")
achternaam = input("Achternaam: ")

print(f"Hallo, {naam} {achternaam}.")
