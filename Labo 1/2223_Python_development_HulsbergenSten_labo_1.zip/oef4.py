# Oefening 4: oppervlakte van een kamer
l = float(input("Lengte (meter): "))
b = float(input("Breedte (meter): "))
o = l * b

print(f"Oppervlakte: {o} meter^2")