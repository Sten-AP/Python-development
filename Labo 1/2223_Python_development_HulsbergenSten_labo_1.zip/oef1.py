# Oefening 1: van start gaan met Python
print("Hallo wereld")
