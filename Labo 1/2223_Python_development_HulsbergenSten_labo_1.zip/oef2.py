# Oefening 2: een visitekaartje afgeven
naam = "Sten"
achternaam = "Hulsbergen"

print(f"{naam}\n{achternaam}")
